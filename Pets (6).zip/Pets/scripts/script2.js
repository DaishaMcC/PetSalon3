//JS
//document.getElementById("sub1").style.display = "none";

//document.getElementById("p");
//for(let i=0;i<p.length;i++){
//    p[i].style.display = "none";
//}

//document.getElementByClassName("bg-black");

//JQuery

//$("#sub1").hide();//by id
//$("p").hide();//by tag
//$(".bg-black").hide();//by class
// What do you prefer

function clickMe(){
    $("#results").hide();
}

function show(){
    $("#results").show();
}