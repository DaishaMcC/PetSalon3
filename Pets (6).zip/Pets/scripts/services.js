let services=[];

//

// constructor
function Service(service,price){
    this.service=service;
    this.price=price;
}

function isValid(service){
    let validation=true; // we are fine
    if(service.service==""){    
    validation=false
    alert("Please add service","error");
    }
    if(service.price==""){
        validation=false
        alert("Please add price","error");
    }
    return validation;  //returning the result of the validation
}

// register function
function register(){
    let inputService = document.getElementById("txtService").value;
    let inputPrice = document.getElementById("txtPrice").value;

    let newService = new Service(inputService,inputPrice);

    if(isValid(newService)){
    showNotification("Service was registered","success")
    save(newService); // it is coming from  storeManager
    $("input").val(""); // clears all the inputs
}
}




